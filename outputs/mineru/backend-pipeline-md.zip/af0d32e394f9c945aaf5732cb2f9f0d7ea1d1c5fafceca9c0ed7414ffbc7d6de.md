# Manual de Utilizador 2018RHV03

Movimentos de Pessoal Militar e Militarizado

<table><tr><td>Data:</td><td>15 Nov. 18</td></tr><tr><td>Versão:</td><td>V.01</td></tr><tr><td>Refº:</td><td>MAN 2018RHV03</td></tr><tr><td>Local:</td><td>SIG - Lisboa</td></tr></table>

# Registo de Alterações

<table><tr><td rowspan=1 colspan=1>Versão</td><td rowspan=1 colspan=1>Data</td><td rowspan=1 colspan=1>Item</td><td rowspan=1 colspan=1>Observações/Pág.</td></tr><tr><td rowspan=1 colspan=1>1.0</td><td rowspan=1 colspan=1>13NOV18</td><td rowspan=1 colspan=1>Versão Inicial</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

# Índice

1. Introdução .. . 5   
2. Explicação do Processo ... . 5   
3. Identificação do movimento a efetuar ....... .... 6   
3.1. Registo e alteração da UOP/GMP/AGPSP/AP ...... ............................................ ...... 6   
3.1.1. Ecrã inicial ... .... 7   
3.1.2. Infotipo 9011 – Movimentos e Mobilidades .. ....... 7   
3.2. Registo e alteração de situação de inamovibilidade ..................................................... 8   
3.2.1. Ecrã inicial ...   
3.2.2. Infotipo 9011 – Movimentos e Mobilidades .. ..... 9   
3.3. Registo de pedido de movimentação / declaração de oferecimento ... .... 10   
3.3.1. Ecrã inicial ... ....... 11   
3.3.2. Infotipo 9011 – Movimentos e Mobilidades .. ..... 11   
3.3.3. Ecrã inicial ... ....... 12   
3.3.4. Infotipo 9009 – Índice de documentos ... ....... 13   
3.4. Identificação dos motivos dos movimentos a efetuar .... ..... 14   
3.5. Extração da Informação ...... ...... 15   
3.5.1. Lista dos militares em situação de inamovibilidade . ... 15   
3.5.2. Lista dos militares que entregaram a declaração – Pedido de movimentação .... ....... 16   
3.5.3. Movimentos “em trânsito / planeado” .. ...... 17   
3.5.4. Síntese de datas (informação do IT0019) ....... ........ 19   
3.5.5. Lista de requerimentos para cessação de contrato ... ...... 20   
3.5.6. Verificação de finais de contratos ...... ....... 21   
3.5.7. Lista de militares saídos no ano e respetivo motivo de saída ............................................ 22   
3.5.8. Lista de licenças registadas ou licenças ilimitadas ....... ....... 24   
3.5.9. Mapa de assiduidades / faltas (mapa por tipo de ausência) .. ......................................... 25   
3.5.10. Juntas Médicas realizadas .. .... 26   
3.5.11. Lista de Punições por posto/categoria e quadro/vínculo .. .... 28   
3.5.12. Lista de participantes .. .... 29   
3.5.13. Escalas .... ........ 30   
4. Colocação do militar em situação transitória.. .. 32   
4.1. Registo da Colocação (trânsito/planeado) .. . 32

4.1.1. Ecrã inicial ...... . 32

# 4.1.2. Infotipo 9011 – Movimentos e Mobilidades ... . 33

5. Concretização do Movimento ...... .. 35

5.1. Colocação no Ramo/Entidade ...... .. 36

5.1.1. Ecrã inicial ... 36   
5.1.2. Medida - Tela Geral .. 37   
5.1.3. Infotipo 0001 – Atribuição Organizacional . . 39   
5.1.4. Infotipo 9011 – Movimentos Mobilidade .. . 41   
5.1.5. Infotipo 0019 - Monitorização de prazos .. . 43

# 5.2. Colocação fora do Ramo ....... .. 45

5.2.1. Ecrã inicial ... 46   
5.2.2. Medida - Tela Geral .. . 47   
5.2.3. Infotipo 0001 – Atribuição Organizacional . . 49   
5.2.4. Infotipo 9011 – Movimentos Mobilidade ... . 51   
5.2.5. Infotipo 0019 - Monitorização de prazos ... 52

# 5.3. Regresso ao Ramo .... . 54

5.3.1. Ecrã inicial ... 54   
5.3.2. Medida - Tela Geral .. . 55   
5.3.3. Infotipo 0001 – Atribuição Organizacional . 57   
5.3.4. Infotipo 9011 – Movimentos Mobilidade .. 59

# 5.4. Diligência/Destacamento . . 60

5.4.1. Ecrã inicial ... 61   
5.4.1. Medida - Tela Geral .. . 62   
5.4.2. Infotipo 0001 – Atribuição Organizacional . . 64   
5.4.3. Infotipo 9011 – Movimentos Mobilidade .. 66   
5.4.4. Infotipo 0019 - Monitorização de prazos . 68

# 5.5. Alteração de situação na unidade.. 69

5.5.1. Ecrã inicial ... 70   
5.5.2. Medida - Tela Geral .. 72   
5.5.3. Infotipo 0001 – Atribuição Organizacional . 73

# 5.6. Suplemento de Residência .. . 75

5.6.1. Ecrã inicial ... . 76   
5.6.2. Infotipo 0006 – Endereços . . 76   
5.6.1. Ecrã inicial .. . 77   
5.6.2. Infotipo 9011 – Movimentos e Mobilidades ... 78

# 5.7. Extração da informação ....... .. 79

5.7.1. Dados necessários à elaboração da Guia de marcha ..... . 79

5.7.2. Listagem dos militares que completam o tempo máximo a receber Suplemento de Residência, numa determinada data . ... 80 5.7.3. Listagem de militares com suplemento de residência processado num determinado período 81 5.7.4. Listagem dos Suplementos de Residência cancelados num determinado período......... 82 5.7.5. Lista de unidades de preferência .. .... 83 5.7.6. Lista de colocações/unidade de colocação ........... ...... 84

# 1. Introdução

Este manual prevê a explicação do processo de implementação das ações relativas à gestão das questões que se referem ao tratamento dos movimentos de pessoal militar e militarizado, dentro dos Ramos/Entidades e entre estes.

O militar pode manifestar a sua preferência por determinada área geográfica e/ ou unidade, estabelecimento, órgão ou serviço (UEOS) para a prestação de serviço, que recebe as seguintes designações consoante o Ramo:

• Marinha: Área e Unidade Orgânica de Preferência (UOP); Exército: Guarnição Militar de Preferência (GMP) ou Área Geográfica de Prestação de Serviço de Preferência (AGPSP) (respetivamente para militares do Quadro Permanente – QP ou em Regime de Voluntariado ou Contrato – RV/RC); Força Aérea: Área e Unidade/Órgão de Preferência (AP).

Esta preferência será tida em conta aquando da sua movimentação, consoante as regras / normas definidas em cada Ramo, que se encontram referidas ao longo deste documento.

# 2. Explicação do Processo

Este processo engloba os seguintes tipos de movimento:

• Colocação;   
• Diligência;   
• Destacamento. No âmbito dos Movimentos de Pessoal Militar, será ainda abordada a gestão de candidaturas $/$ atribuição ao/do Suplemento de residência.   
Será ainda abordado o tema do desempenho de funções de dirigente por parte de um militar (comissão especial, desempenhada fora do Ramo) e ainda a nomeação do militar para missões, ações de cooperação técnico-militar, cargos e cursos no estrangeiro.

Os movimentos de pessoal militar são efetuados em 3 momentos distintos:

1. Identificação do movimento a efetuar (1.ª fase) – abertura do convite e receção de candidaturas (quando aplicável); análise e seleção do militar que será movimentado;   
2. Colocação numa situação transitória (2.ª fase) – o militar é colocado como “em trânsito/planeado” no sistema aplicacional;   
3. Concretização do movimento propriamente dito $3 ^ { \mathsf { a } }$ fase) – execução da medida associada à movimentação propriamente dita com a indicação da entidade destino para a qual vai o militar.

# 3. Identificação do movimento a efetuar

Na primeira fase é detetado o movimento a efetuar, existindo posteriormente uma análise e seleção do militar que será movimentado.

Neste ponto do documento serão abordados os seguintes temas:

• Registo e alteração da UOP/GMP/AGPSP/AP;   
• Registo e alteração de situação de inamovibilidade;   
• Registo de pedido de movimentação / declaração de oferecimento;   
• Identificação de movimentos a efetuar;   
• Escalas.

# 3.1. Registo e alteração da UOP/GMP/AGPSP/AP

A informação relativa à UOP/GMP/AGPSP/AP estará registada no IT “Informação sobre Movimentos/Mobilidades”, mais precisamente do subtipo “Área de Preferência”. A alteração desta informação não implica a criação de uma medida específica, mas sim a atualização de um registo deste IT no cadastro do militar. O histórico referente à área de preferência fica assegurado e residirá no sistema aplicacional desde o momento da escolha inicial que é efetuada aquando da primeira colocação, até às alterações que poderão ocorrer ao longo da vida do militar.

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre → Registo &quot; Atualizar</td></tr><tr><td>Código de Transação</td><td>PA30</td></tr></table>

# 3.1.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

# Atualizar dados mestre HR

![](images/1839122cf5a90c3dd43fc575806d1ed971a9296ce45d259dc0a6b776e6a459e3.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Infotipo</td><td rowspan=1 colspan=1>9011  Movimentos Mobilidades</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Subtipo</td><td rowspan=1 colspan=1>0001 - Área de Preferência</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Criar</td><td rowspan=1 colspan=1>□</td><td rowspan=1 colspan=1></td></tr></table>

# 3.1.2. Infotipo 9011 – Movimentos e Mobilidades

Preencher os seguintes campos:

![](images/822da4906b83acd08feb4ce8191de977c94b183349c763b9546bcd475590dcee.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Válido de</td><td rowspan=1 colspan=1>A preencher com a data de início doregisto (dia atual)</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Válido até</td><td rowspan=1 colspan=1>A preencher com a data de fim doregisto</td><td rowspan=1 colspan=1>Deve ser colocada a data31.12.999 quando não éconhecida a priori a data fim.2</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Área Preferência</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1>Deve ser selecionada a área depreferência.</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Unidade Preferência</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1>Deve ser selecionada a unidade/ órgão de preferência.</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Data entrega da declaração depreferência</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1>Obrigatório</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Data do despacho autorizador</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1>Obrigatório</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1></td></tr></table>

# 3.2. Registo e alteração de situação de inamovibilidade

Para que sejam identificados os militares que se encontram em situação de inamovibilidade, deve ser criado um novo registo no IT “Informação sobre Movimentos/Mobilidades”, mais precisamente do subtipo “Inamovibilidade”.

Nos casos em que existe prorrogação da situação de inamovibilidade, o utilizador deve criar novos registos e indicar a prorrogação a que dizem respeito, com data de validade coincidente com o período de prorrogação concedido.

<table><tr><td>Menu</td><td>HR  Recursos Humanos  Dados Mestre  Registo → Atualizar</td></tr><tr><td>Código de Transação</td><td>PA30</td></tr></table>

# 3.2.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

# Atualizar dados mestre HR

![](images/87a9a29e53e8026bd5880f93f76c6084d0f1c4d122e198247c6baf39cfd88b1e.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Infotipo</td><td rowspan=1 colspan=1>9011  Movimentos Mobilidades</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Subtipo</td><td rowspan=1 colspan=1>0003 - Inamovibilidade</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Criar</td><td rowspan=1 colspan=1>□</td><td rowspan=1 colspan=1></td></tr></table>

# 3.2.2. Infotipo 9011 – Movimentos e Mobilidades

Preencher os seguintes campos:

![](images/1a40f583cf184ab01376718701bac72b07233381b8f99a2f305e26b95e95c9f8.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Válido de</td><td rowspan=1 colspan=1>A preencher com a data de início doregisto (dia atual)</td><td rowspan=1 colspan=1>Deve ser inserida a data deinício da situação deinamovibilidade.</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Válido até</td><td rowspan=1 colspan=1>A preencher com a data de fim doregisto</td><td rowspan=1 colspan=1>Deve ser colocada a data até àqual o militar se encontra emsituação de inamovibilidade.</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Situação</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1>Obrigatório.Deve ser indicada se o registocorresponde à situação inicialde inamovibilidade ou umaprorrogação (1ª, 2ª ou 3ª).</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Órgão</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1>Obrigatório.Deve ser selecionado o Órgão aque o militar pertence e que éum elemento caracterizador dasituação de inamovibilidade.</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Função</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1>Obrigatório.Selecionar a função que omilitar exerce e que também elacaracteriza a situação emquestão.</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1></td></tr></table>

# 3.3. Registo de pedido de movimentação / declaração de oferecimento

Para registar quais os militares que, por oferecimento, se propõem a serem colocados em determinada UEOS, deve ser criado aquando da receção da declaração do militar, no seu cadastro, um novo registo no infotipo IT “Informação sobre Movimentos/Mobilidades”, mais precisamente do subtipo “Pedido de Movimentação”.

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre  Registo &quot; Atualizar</td></tr><tr><td>Código de Transação</td><td>PA30</td></tr></table>

# 3.3.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

# Atualizar dados mestre HR

![](images/784b482d9bffb3a255b0a56516e2a4629656c3b25d3b04075ae6fc3e1d367ce3.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Infotipo</td><td rowspan=1 colspan=1>9011  Movimentos Mobilidades</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Subtipo</td><td rowspan=1 colspan=1>0002 - Pedido de movimentação/mobilidade</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Criar</td><td rowspan=1 colspan=1>□</td><td rowspan=1 colspan=1></td></tr></table>

# 3.3.2. Infotipo 9011 – Movimentos e Mobilidades

Preencher os seguintes campos:

![](images/ac1768198991f9738d0e61081a3c50bcf8eaa6b144a3a1a91a19b2f2d61a040e.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Válido de</td><td rowspan=1 colspan=1>A preencher com a data de início doregisto (dia atual)</td><td rowspan=1 colspan=1>Deve ser inserida a data dopedido.</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Válido até</td><td rowspan=1 colspan=1>A preencher com a data de fim doregisto</td><td rowspan=1 colspan=1>Deve ser colocada a data até àqual o pedido é válido.</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Data de entrega do requerimento</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1>Obrigatório.Deve ser registada a data dareceção da declaração.</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Data do despacho autorizador</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1>Obrigatório.</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Unidade Organizacional</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1>Obrigatório.Deve ser colocada a UEOS naqual o militar manifestapreferência de colocação.</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1></td></tr></table>

Sempre que haja necessidade de arquivar documentação no processo individual do militar (por exemplo, declaração de preferência ou declaração a solicitar movimentação), deve ser atualizado o IT “Índice de Documentos”. Os procedimentos a adotar para o preenchimento deste IT encontram explicados no Manual do processo 3.1. Processo Individual.

# 3.3.3. Ecrã inicial

Preencher os seguintes campos obrigatórios:

![](images/9431dc505aaa8e2531132b65b81d52a59cf058fc13f3c7620e298d223bf80eef.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Nº de pessoal</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Infotipo</td><td rowspan=1 colspan=1>9009  Índice de documentos</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Subtipo</td><td rowspan=1 colspan=1>0001 - PIND</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Criar</td><td rowspan=1 colspan=1>□</td><td rowspan=1 colspan=1></td></tr></table>

# 3.3.4. Infotipo 9009 – Índice de documentos

Preencher os seguintes campos:

![](images/2576e590fccbaeeb9063c94eeab6408bceed34a18d45fc64da2bff8186b7f05c.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Válido de</td><td rowspan=1 colspan=1>A preencher com a data de inicio doregisto (dia atual)</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Válido até</td><td rowspan=1 colspan=1>A preencher com a data de fim doregisto</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>N° Sequencial</td><td rowspan=1 colspan=1>Preenchimento automático</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Tipo de Documento</td><td rowspan=1 colspan=1>26 - Declaração de preferência</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Data do documento</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Descrição</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Observações</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1></td></tr></table>

# 3.4. Identificação dos motivos dos movimentos a efetuar

A necessidade de efetuar um movimento poderá surgir por diversos motivos. Neste ponto irão ser enumeradas algumas dessas situações, que poderão ser verificáveis com o auxílio do sistema. Na tabela seguinte é apresentada a situação que poderá originar um movimento, o processo correspondente (i.e. o processo no âmbito deste projeto em que a situação é detalhada) e a ferramenta de reporting disponibilizada pelo sistema (que se encontra igualmente identificada no ponto 3.5. Extração da Informação deste documento) que terá como objetivo a consulta de dados existentes no sistema que poderão originar um movimento:

<table><tr><td rowspan=1 colspan=1>Situação</td><td rowspan=1 colspan=1>Processo</td><td rowspan=1 colspan=1>Ferramenta de reporting</td></tr><tr><td rowspan=1 colspan=1>Nomeação para comissão: militarescom movimentos já planeados</td><td rowspan=1 colspan=1>3.4 Movimentos - PessoalMilitar e Militarizado</td><td rowspan=1 colspan=1>Movimentos &quot;em trânsito /planeado&quot;</td></tr><tr><td rowspan=1 colspan=1>Fim de comissão: militares cujacolocação / diligência se encontra aterminar</td><td rowspan=1 colspan=1>3.4 Movimentos - PessoalMilitar e Militarizado</td><td rowspan=1 colspan=1>Síntese de datas (informação doIT0019)</td></tr><tr><td rowspan=1 colspan=1>Pedido de rescisão do regime de 4.9 Saídas - Pessoal Militarcontrato</td><td rowspan=1 colspan=1>4.9 Saldas — Pesoa Mmilitar</td><td rowspan=1 colspan=1>Lista de requerimentos paracessação de contrato</td></tr><tr><td rowspan=1 colspan=1>Saídas de militares: Fim do regimede contrato, passagem à situação dereserva fora da efectividade deserviço, abate ao QP, passagem àreforma</td><td rowspan=1 colspan=1>4.9 Saídas - Pessoal Militar</td><td rowspan=1 colspan=1>Verificação de finais decontratos e/ou Lista de militaressaídos no ano e respectivomotivo de saída</td></tr><tr><td rowspan=1 colspan=1>Licença registada ou ilimitada</td><td rowspan=1 colspan=1>3.2 Assiduidades</td><td rowspan=1 colspan=1>Lista de licenças registadas oulicenças ilimitadas</td></tr><tr><td rowspan=1 colspan=1>Parentalidade</td><td rowspan=1 colspan=1>3.2 Assiduidades</td><td rowspan=1 colspan=1>Mapa de assiduidades / faltas(mapa por tipo de ausência)</td></tr><tr><td rowspan=1 colspan=1>Alteração da situação de Saúde oubaixa por período prolongado(decorrente de uma decisão da JuntaMédica)</td><td rowspan=1 colspan=1>3.7 Gerir Juntas Médicas</td><td rowspan=1 colspan=1>Juntas Médicas realizadas</td></tr><tr><td rowspan=1 colspan=1>Pena disciplinar</td><td rowspan=1 colspan=1>5.3 Gerir processos deaveriguações e disciplinares</td><td rowspan=1 colspan=1>Lista de Punições porposto/categoria e quadro/vínculo</td></tr><tr><td rowspan=1 colspan=1>Frequência de curso: militaresinscritos num curso de formação</td><td rowspan=1 colspan=1>4.5 Realização da formação</td><td rowspan=1 colspan=1>Lista de participantes</td></tr></table>

Algumas das situações enumeradas correspondem também a situações que podem ser impeditivas da realização de um movimento para determinado militar (por exemplo, o militar encontra-se nomeado para a frequência de determinado curso de formação), logo as ferramentas de reporting apresentadas poderão igualmente ter a finalidade de verificar se determinado militar se encontra disponível para ser movimentado.

# 3.5. Extração da Informação

# 3.5.1. Lista dos militares em situação de inamovibilidade

<table><tr><td>Menu</td><td>HR  Recursos Humanos &quot; Gestão de Pessoal → Movimentação de Pessoal Militar → Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0005</td></tr></table>

Preencher os seguintes campos:

![](images/ae067591c0309d1b5ff382d4d2213110505bf2d703e135090ffd44a7a63a7fda.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Chamar variante</td><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Opção</td><td colspan="1" rowspan="1">INAMOVIBILIDAD</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Selecionar</td><td colspan="1" rowspan="1">V</td><td colspan="1" rowspan="1"></td></tr><tr><td>4</td><td>N° Pessoal</td><td>A Preencher com o N° de pessoal</td><td></td></tr><tr><td>5</td><td>Área de Recursos Humanos</td><td></td><td></td></tr><tr><td>6</td><td>Subtipo</td><td>Secionar o tipo de movimento para o qual pretende visualizar a lista: 0003 - Inamovibilidade</td><td></td></tr><tr><td>7</td><td>Executar</td><td>+</td><td></td></tr></table>

3.5.2. Lista dos militares que entregaram a declaração – Pedido de movimentação

<table><tr><td>Menu</td><td>HR - Recursos Humanos →</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0006</td></tr></table>

Preencher os seguintes campos:

![](images/48c05cec7bd475c9f969199b7736f1fce0b9ffbf5acbef60eb539c2aecd5819b.jpg)

<table><tr><td>#</td><td>Campo / Operação</td><td>Valores</td><td>Comentários</td></tr></table>

<table><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>t</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>PEDIDO MOVIMENTAÇÃO</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o Nº de pessoal</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Subtipo</td><td rowspan=1 colspan=1>Secionar o tipo de movimento para o qualpretende visualizar a lista:0002 - Pedido de movimentação/mobilidade</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>0</td></tr></table>

# 3.5.3. Movimentos “em trânsito / planeado”

<table><tr><td>Menu</td><td>HR - Recursos Humanos  Gestão de Pessoal → Movimentação de Pessoal Militar → Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0032</td></tr></table>

Preencher os seguintes campos:

![](images/3f3454aca16d573b200cad279f07f39573b2732a65065c9ae95edc4d4c70722f.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>Transito/Plan</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o N° de pessoal</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Subtipo</td><td rowspan=1 colspan=1>Secionar o tipo de movimento para o qualpretende visualizar a lista:0001 - Área de preferência0002 - Pedido de movimentação/mobilidade0003 - Inamovibilidade0004 - Diligências/Destacamentos0005 - Colocações</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Status do movimento</td><td rowspan=1 colspan=1>1 - Em trânsito/planeado</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>O</td><td rowspan=1 colspan=1></td></tr></table>

# 3.5.4. Síntese de datas (informação do IT0019)

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre  Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0016</td></tr></table>

Preencher os seguintes campos:

# Monitorização de Prazos

![](images/ccc54987e09ae3091ae408df6e1e0dee0a652a210716cfb789b127c5a0496411.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Chamar variante</td><td colspan="1" rowspan="1">F</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Opção</td><td colspan="1" rowspan="1">FIM COLOCAÇÃO</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Selecionar</td><td colspan="1" rowspan="1">V</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Nº Pessoal</td><td colspan="1" rowspan="1">A Preencher com o Nº de pessoal</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Área de Recursos Humanos</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">Tipo de data/prazo</td><td colspan="1" rowspan="1">e.g 09 - Fim Colocaçãoe.g Marinha:10 - Fim Comissão terra</td><td colspan="1" rowspan="1"></td></tr><tr><td></td><td></td><td>11 - Fim ComissãoEmbarque 12 - Fim ComissãoDur.esp.</td><td></td></tr><tr><td>7</td><td>Data do lembrete</td><td>Preencher se pretender identificar todos os registos de datas com determinada data de lembrete</td><td></td></tr><tr><td>8</td><td>Executar</td><td>O</td><td></td></tr></table>

# 3.5.5. Lista de requerimentos para cessação de contrato

<table><tr><td>Menu</td><td>HR - Recursos Humanos  Gestão de Pessoal → Processo Individual → Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0010</td></tr></table>

Preencher os seguintes campos:

![](images/e26704aa71f6d978bc0edb4c0366660e04b218f91b075ac737ebfddaf43d2597.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>REQ.CESSAÇÃO</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o N° de pessoal</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Tipo de Documento</td><td rowspan=1 colspan=1>Selecionar o tipo de documento para o qualpretende obter informação:25- Requerimento cessação de contrato</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Descrição</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>+</td></tr></table>

# 3.5.6. Verificação de finais de contratos

<table><tr><td>Menu</td><td>HR - Recursos Humanos →</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0028</td></tr></table>

Preencher os seguintes campos:

![](images/72391c178535be966ecd432520453196fa4c42ab3fc0c1a50a6495f5755222d4.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>FIM CONTRATO</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o Nº de pessoal</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Data de fim do contrato</td><td rowspan=1 colspan=1>Se se pretender procurar os contratos queforam finalizados em determinada data,preenche-se o campo com a data aanalisar.</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>o</td><td rowspan=1 colspan=1></td></tr></table>

# 3.5.7. Lista de militares saídos no ano e respetivo motivo de saída

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre &quot; Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0020</td></tr></table>

Preencher os seguintes campos:

# Lista de Medidas

![](images/e0a7473feb0d7274ee58266ee920ebfb07bd5c84df5d7922acef639b567ab1eb.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>MIL. SAÍDOS</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o Nº de pessoal</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Tipo de medida</td><td rowspan=1 colspan=1>BO - Saída</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Motivo</td><td rowspan=1 colspan=1>01 - Fim colocação militar02 - Fim de mobilidade03 - Eliminação curso QP04 - Desistência curso QP</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>O</td><td rowspan=1 colspan=1></td></tr></table>

# 3.5.8. Lista de licenças registadas ou licenças ilimitadas

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre → Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0020</td></tr></table>

Preencher os seguintes campos:

![](images/653491bd2a0ddb96b038ec0d9208deee577001256fd7e5ad2771aef4f0512b8f.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Chamar variante</td><td colspan="1" rowspan="1">$</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Opção</td><td colspan="1" rowspan="1">Lic.Reg.llimit</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Selecionar</td><td colspan="1" rowspan="1">V</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Nº Pessoal</td><td colspan="1" rowspan="1">A Preencher com o N° de pessoal</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Área de Recursos Humanos</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">Medida</td><td colspan="1" rowspan="1">AM - Início de licença ilimitadaAK - Início licença s/remuneração</td><td colspan="1" rowspan="1"></td></tr><tr><td>7</td><td>Motivo</td><td>01 - Coloc.Org.Externo c/Proc.Part.</td><td></td></tr><tr><td>8</td><td>Executar</td><td>O</td><td></td></tr></table>

# 3.5.9. Mapa de assiduidades / faltas (mapa por tipo de ausência)

<table><tr><td>Menu</td><td>HR  Recursos Humanos  Gestão de Pessoal &quot; Assiduidades → Relatórios</td></tr><tr><td>Código de Transação</td><td>PT64</td></tr></table>

Preencher os seguintes campos:

![](images/133d2e0904647e721f713773eb57bc94ad703bfcc8d06f30030b4a9f6aa64580.jpg)

Edição de dados

Agrp.por atribuição orga

Não exibir textos para atrbuição organizacional $\bigcirc \mathsf { S } _ { 0 } ^ { \mathsf { \Lambda } }$ exibir textos para atribuição organizacional $\odot$ Exibir textos adicionalmente para atrbuição organizacional

![](images/b03f44e96e9db8980c97d3121b86a8b4fc77d920e43d63799968b0988ea6c3ba.jpg)

Dados a exibir

$\odot 5 6$ exibir emps.c/tps.ausên.correspond Exib.tds.empregs.

![](images/c0ca8ed904a493a2d842af2d88f9a70d5d0c2e34647855044f48026a22371409.jpg)

Detalhes dos dados na lista inicial por

Atrib.organiz.   
Atrbuição org. - empregados   
Atribuição org.- TpsAusência/presença   
Atribuição org. - empregados- tipos ausência/presença Atrbuição org.- tipos ausência/presença - empregados

![](images/5220a2ccd9ada90e1fcb454c7d28e4554a5b588e3d834536e170a95dc316cd63.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>MAPA ASSIDUID</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o Nº de pessoal</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Tipo de ausência</td><td rowspan=1 colspan=1>Se pretender analisar um tipo deassiduidade/falta, deve especifica-lo quie 1013 - Assist membro agreg famil</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>e.g &quot;Só analisar ausências&quot;√        Só analisar ausências</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>e.g &quot;Exibir textos adicionalmente para aatribuição organizacional&quot;xr</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>e.g&quot;Só exibir EE c/tps.ausên.corresponds&quot; xir Etpausn.coreson.</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>e.g Atribuição org. - tipos ausência/presençaempregados&quot;trbuiçotipo ausênci/psença - eo</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>O</td></tr></table>

# 3.5.10. Juntas Médicas realizadas

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre  Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0002</td></tr></table>

Preencher os seguintes campos:

# Juntas Médicas

![](images/c263b5b51702de7605be2f22c37edc8332e4cac90afb75e2fca636b10ac6fe4a.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>JUNTAS MÉDICAS</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o Nº de pessoal</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Data da ocorrência</td><td rowspan=1 colspan=1>Preenchendo o campo extrair-se-á os registosde Juntas Médicas para a data inserida.</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>O</td><td rowspan=1 colspan=1></td></tr></table>

# 3.5.11. Lista de Punições por posto/categoria e quadro/vínculo

<table><tr><td>Menu</td><td>HR - Recursos Humanos  Justiça e Disciplina  Processos Disciplinares, Criminais e Punições/Penas</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0026</td></tr></table>

Preencher os seguintes campos:

![](images/44b86d387e52e902362467f9e79d88d3f1ee6e056df2cd4f161bd36a19883eec.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>PUNICOES_MILIT</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o Nº de pessoal</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Tipo de Pena</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>④</td><td rowspan=1 colspan=1></td></tr></table>

# 3.5.12. Lista de participantes

<table><tr><td>Menu</td><td>HR - Recursos Humanos  Gestão de Pessoal  Processo Individual Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0057</td></tr></table>

Preencher os seguintes campos:

![](images/ee05b42ae33402f4a7cb416d73343e6649a08151823f8e647b595b1e5ef5f679.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>$</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>PARTICIPANTES</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Nº Pessoal</td><td rowspan=1 colspan=1>A Preencher com o Nº de pessoal</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Formação</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1></td></tr></table>

# 3.5.13. Escalas

Para auxiliar a produção das escalas (escalas de embarque, escalas de deslocamento e escalas, respetivamente da Marinha, Exército e Força Aérea), poderá ser realizada uma consulta ao sistema, mais precisamente à informação registada no cadastro do militar.

<table><tr><td>Menu</td><td>HR - Recursos Humanos → Gestão de Pessoal → Movimentação de Pessoal Militar → Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_ESCALAS</td></tr></table>

Preencher os seguintes campos:

# Escalas

![](images/297dd5078da3a09da5aa02a4ab0697d857c5f797234a8379b617bc2abca6814e.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>ESCALA</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o Nº de pessoal</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>O</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td>Menu</td><td>HR - Recursos Humanos  Gestão de Pessoal → Movimentação de Pessoal Militar → Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_ESC_EMBARQUE</td></tr></table>

Preencher os seguintes campos:

![](images/52c4235ad64df8b1dcb2092f9dab8d00519eda4bd71460d2ca97168905a206b6.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>ESCALA EMBARQUE</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Nº Pessoal</td><td rowspan=1 colspan=1>A Preencher com o Nº de pessoal</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>OP</td><td rowspan=1 colspan=1>Preencher</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>+</td><td rowspan=1 colspan=1></td></tr></table>

# 4. Colocação do militar em situação transitória

Após identificada a necessidade de operar o movimento, é necessário solicitar autorização para que o mesmo ocorra. Desta forma, é elaborada uma informação do movimento para aprovação superior onde consta a finalidade do movimento, a situação da UEOS e do militar, a análise efetuada sobre a viabilidade do movimento, uma conclusão e uma proposta para aprovação superior. Esta solicitação é efetuada de forma externa ao sistema.

# 4.1. Registo da Colocação (trânsito/planeado)

Caso o movimento seja autorizado, é comunicada a autorização, a data de movimentação e o Despacho que lhe deu origem, às entidades envolvidas (UEOS de origem e de destino). Após a receção desta informação, o utilizador deve dar início ao processamento do movimento no sistema aplicacional. Esta ação traduz-se na criação do $I T$ “Informação sobre Movimentos/Mobilidades”, mais precisamente do subtipo “Colocações”.

A informação registada em sistema permite emitir a Guia de marcha que deve acompanhar o militar quando se desloca para fora da sua UEOS.

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre  Registo  Atualizar</td></tr><tr><td>Código de Transação</td><td>PA30</td></tr></table>

# 4.1.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

# Atualizar dados mestre HR

#

![](images/abb5c8dd46ff49033d58bda3798bcf35534ea2d3e2150d89180c01153a111771.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Infotipo</td><td rowspan=1 colspan=1>9011  Movimentos Mobilidades</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Subtipo</td><td rowspan=1 colspan=1>0005 - Colocações/Destacamentos</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Criar</td><td rowspan=1 colspan=1>□</td><td rowspan=1 colspan=1></td></tr></table>

# 4.1.2. Infotipo 9011 – Movimentos e Mobilidades

Preencher os seguintes campos:

![](images/b41a3e4a233f36d88ba691d39294b59a8fbd04910ce0b9ed9267cce4b1131dd4.jpg)

# Movimentos mobilidades criar

![](images/4d7151d7e3f5411e9bfbd06b34cd008ec0bfef50c60e502eb062c44494fec564.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Válido</td><td rowspan=1 colspan=1>A preencher com a data de início doregisto (dia atual)</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Válido até</td><td rowspan=1 colspan=1>A preencher com 31.12.9999</td><td rowspan=1 colspan=1>Deve ser colocada a data31.12.9999     quando    omovimento está autorizado, maso militar ainda não seapresentou na UEOS destino(status “em trânsito/planeado”);no momento em que o militar seapresenta na UEOS destino epassa à situação de “colocado”,esta data será delimitada.</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Unidade Destino</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>Deve ser selecionada a unidadeorganizacional para a qual omilitar se movimentará.</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Unidades destino Externas</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>Deve ser selecionada a unidadeexterna para a qual o militar semovimentará.</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Colocação</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Data Prevista</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Registar    a    data   demovimentação    que    foipreviamente autorizada.</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Tipo Nomeação</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Tipo Colocação</td><td rowspan=1 colspan=1>Selecionar</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>Tipo Comissão</td><td rowspan=1 colspan=1>Selecionar</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>Urgência Movimento</td><td rowspan=1 colspan=1>Selecionar</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>Status Movimento</td><td rowspan=1 colspan=1>1 - Em trânsito/planeado</td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>Data Limite para Movimento</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td></tr></table>

# 5. Concretização do Movimento

Quando o militar se apresenta na UEOS destino, esta deve recebê-lo e registar a sua apresentação, consoante o tipo de movimento em questão (colocação, diligência ou destacamento). Esta ação traduz-se na criação de uma das Medidas a seguir apresentadas.

No âmbito das colocações, é necessário definir as seguintes situações que exigem um registo diferenciado no sistema:

• Colocação no Ramo;

• Colocação fora do Ramo:

o Com processamento de vencimentos partilhado entre o Ramo e a entidade de destino;   
o Sem processamento de vencimentos por parte do Ramo (ficando este totalmente ao encargo da entidade de destino);   
o Em qualquer um dos dois casos apresentados, a entidade de destino (se pertencente ao MDN) deverá registar a apresentação do militar;   
o Igualmente em qualquer um dos dois casos, aquando do regresso do militar ao Ramo, deverá ser registada a medida que indica esta situação e que repõe a responsabilidade do processamento de vencimentos ao cargo do Ramo (ou a mantém, para o caso em que o processamento se manteve inalterado); a entidade que o acolheu deverá registar a sua “saída”.

Através do registo das medidas que representam as situações enumeradas, o sistema irá copiar determinados IT (com base nos IT já existentes), cuja informação será alterada pelo utilizador, indicando o período a partir do qual são válidos os novos dados acerca do militar; outros registos serão delimitados, pois deixarão de estar válidos.

Todas as medidas associadas a colocações irão copiar o IT “Informação sobre Movimentos/Mobilidades”, mais precisamente o subtipo “Colocações” já criado (aquando do planeamento do movimento), onde o militar se encontra no status “em trânsito/planeado” e criar um novo registo com a data de início igual à data do movimento, onde o status será alterado para “Colocado” (com esta ação, a informação anterior correspondente ao planeamento é delimitada ao dia anterior ao do movimento). Desta forma, a informação ficará coerente com a informação que constará do IT0001 – Atribuição Organizacional, onde ficará registada a alocação do militar à UEOS para onde foi movimentado. A informação deste IT permite emitir a Guia de marcha que deve acompanhar o militar quando se desloca para fora da sua UEOS.

Sempre que for executada uma medida correspondente a uma colocação, o sistema irá propor a criação do IT0019 – Monitorização de prazos com o tipo de prazo “Fim de colocação” (ou, na Marinha, “Fim de comissão terra”, “Fim de comissão embarque” ou “Fim comissão duração especial”), de modo a que o utilizador possa indicar a data prevista para o final da colocação correspondente. Os registos deste IT podem ser consultados através do relatório Síntese de datas.

# 5.1. Colocação no Ramo/Entidade

A Medida Colocação (no Ramo/Entidade) deve ser criada sempre que um militar for colocado noutra UEOS, dentro do Ramo. Esta medida deve ser executada aquando da apresentação do militar na unidade de destino; quando esta colocação termina, o militar irá para uma nova unidade de destino, onde também será registada uma medida que representa essa colocação e assim sucessivamente. A figura das trocas/permutas encontra-se enquadrada neste ponto. Quando existir uma troca/permuta entre militares, deverá ser executada esta medida para cada um deles (com a indicação do motivo correspondente a esta situação), sendo estes colocados nas Posições respetivas em termos de estrutura organizacional.

<table><tr><td>Menu</td><td>HR  Recursos Humanos &quot; Dados Mestre &quot; Registo → Medidas</td></tr><tr><td>Código de Transação</td><td>PA40</td></tr></table>

# 5.1.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

![](images/ede4c4132b30fd2a90fc218a49f46e687f5bc9d0795c04b285f76526ce7499c5.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Selecionar medida</td><td rowspan=1 colspan=1>AP  Colocação (no Ramo/Entidade)</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>Preencher com o N° de pessoal para oqual se vai efetuar a alteração</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Início</td><td rowspan=1 colspan=1>A preencher com a data do motivo damedida</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>+</td><td rowspan=1 colspan=1></td></tr></table>

# 5.1.2. Medida - Tela Geral

Preencher os seguintes campos:

![](images/e4f45d972b619fdcd7e3e52381cdd1a7140bd19246e733790bbf16c2f9787db7.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">N° de pessoal</td><td colspan="1" rowspan="1">Preenchimento automático</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Válido</td><td colspan="1" rowspan="1">Preenchimento automático</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Válido até</td><td colspan="1" rowspan="1">Preenchimento automático</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Medida</td><td colspan="1" rowspan="1">Preenchimento automático  APColocação (no Ramo/Entidade)</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Motivo da medida</td><td colspan="1" rowspan="1">01 - Colocaçãoou02  Troca/Permuta</td><td colspan="1" rowspan="1"></td></tr><tr><td>6</td><td>Posição</td><td>A preencher</td><td></td></tr><tr><td>7</td><td>Área de Recursos Humanos</td><td>Manter valor</td><td></td></tr><tr><td>8</td><td>Grupo de Empregados</td><td>Manter valor</td><td></td></tr><tr><td>9</td><td>Subgrupo de Empregados</td><td>Manter valor</td><td></td></tr><tr><td>10</td><td>Gravar</td><td>8</td><td></td></tr></table>

# 5.1.3. Infotipo 0001 – Atribuição Organizacional

Preencher os seguintes campos:

![](images/dea7ef1d8ac5c1509068cf516eb8c27331ddffdb598b95734306931a64e2723d.jpg)

![](images/9ff53609d047e8d6cffa22113d8e2c87209703cc027cfb80c46fc88683d3e51a.jpg)

# Atribuição organizacio7 Copia

#

#

Administração da organização info..

![](images/126ee4a395e7b6b4c2ff0049d936c51fafa2adbbb0c953fe397248ab3a413a8d.jpg)

![](images/3e3bb86833541ef0f12709a24b92d542e54732335cff195fb5e5d3e6b73dea23.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Centro Financeiro</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Deverá ser utilizada a ajuda depesquisa para selecionar o valormais adequado para o efeito</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Fundos</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Área Funcional</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Relação de emprego</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Este campo deverá serpreenchido quando o indivíduo</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">contratado seja pago pororganismo externo</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Chave Organizativa</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Preenchido automaticamente</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">Situação na Unidade</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Campo exclusivo da Marinha</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">Gravar</td><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1"></td></tr></table>

# 5.1.4. Infotipo 9011 – Movimentos Mobilidade

Preencher os seguintes campos do Subtipo 0005 – Colocações/Destacamentos:

![](images/613b1be8fe4c57a8402d25a6d19b806ddb4669a351b533076a9e8bd88cc8045b.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Válido</td><td rowspan=1 colspan=1>A preencher com a data de inicio damobilidade</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Válido até</td><td rowspan=1 colspan=1>A preencher com 31.12.9999</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Unidade Destino</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Unidades destino Externas</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Data Prevista</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Data despacho autorizador</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Entidade que Autoriza</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Tipo Nomeação</td><td rowspan=1 colspan=1>Selecionar</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>Tipo Colocação</td><td rowspan=1 colspan=1>Selecionar</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>Tipo Comissão</td><td rowspan=1 colspan=1>Selecionar</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>Urgência Movimento</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>Status Movimento</td><td rowspan=1 colspan=1>2 - Realizado</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>Data Limite para Movimento</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td></tr></table>

![](images/19e528462fc24ff96f39eef7d5942e7b1ee9f6c3f9b602a28e2561c705611c0b.jpg)

![](images/08e46dda7be9023812a3181b05d438dd3834b1325ceab9a009ae77c36142dbff.jpg)

# Movimentos mobilidades criar

#

![](images/30c148122aac72b8c0731cc063e61aa17572a70b6447ad0aa9aadd3201438f66.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Válido de</td><td colspan="1" rowspan="1">A preencher com a data de início doregisto (dia atual)</td><td colspan="1" rowspan="1">Deve ser inserida a data deinício   da  situação deinamovibilidade.</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Válido até</td><td colspan="1" rowspan="1">A preencher com a data de fim doregisto</td><td colspan="1" rowspan="1">Deve ser colocada a data até àqual o militar se encontra emsituação de inamovibilidade.</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Situação</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Obrigatório.Deve ser indicada se o registocorresponde à situação inicialde inamovibilidade ou umaprorrogação (1ª, 2ª ou 3ª).</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Órgão</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Obrigatório.Deve ser selecionado o Órgão aque o militar pertence e que éum elemento caracterizador dasituação de inamovibilidade.</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Função</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Obrigatório.Selecionar a função que omilitar exerce e que também elacaracteriza a situação emquestão.</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">Gravar</td><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1"></td></tr></table>

# 5.1.5. Infotipo 0019 - Monitorização de prazos

Preencher os seguintes campos, exclusivamente para o motivo 01-Colocação. Para a Consolidação e Fim de mobilidade deve passar ao registo seguinte:

![](images/90b6419b4cfeab8e3b31eebae88526921f14bb9f37ba70893266a7c4cd5ebeec.jpg)

# Monitorização de prazus criar

#

![](images/b83635431ef5aa1236a6413f5dc9644ee14f26ef1f85ab7a70161b951eb5d2bc.jpg)

![](images/728aa466ff1d249c037f94221f4111651c73cbd22889c586ef087cd8220b9703.jpg)

![](images/588929085f0afaab540a41d09f4da6aeca5fbf7adf89848e3542a6b009ded0c8.jpg)

Específico de tipo de datas/prazos

# Observações

![](images/d640ff5d8ed03dcb441357dbe23d56d457ad8cf48725fea0d2386a7dac98cff8.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Tipo de Datas/Prazos</td><td rowspan=1 colspan=1>e.g Fim Mobilidade</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Data em</td><td rowspan=1 colspan=1>Preencher</td><td rowspan=1 colspan=1>Data Fim da Mobilidade</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Código de processamento</td><td rowspan=1 colspan=1>e.g Data nova</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Data de lembrete</td><td rowspan=1 colspan=1>e.g. 01.12.2015</td><td rowspan=1 colspan=1>Data para lembrete do Fim daMobilidade</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1></td></tr></table>

De seguida vão surgir diversos Infotipos que só devem ser preenchidos caso seja necessário alterar/criar algum dado:

Infotipo 0007 – Horário de Trabalho;   
Infotipo 0050 – Informação de Registo de Tempos; Infotipo 0008 - Remuneração Base;   
Infotipo 0337 – Posto / Categoria Profissional;   
Infotipo 0332 – Dados Segurança Social / CGA;   
Infotipo 0014 – Remunerações / Deduções Periódicas;   
Infotipo 0057 – Afiliações;   
Infotipo 0045 – Empréstimos / Prestações.

# 5.2. Colocação Fora do Ramo

A Medida Colocação (F. Ramo Est. Org. FFAA) deverá ser executada quando o militar é colocado noutra entidade (pertencente à Estrutura Orgânica das Forças Armadas), sendo o processamento do seu vencimento da responsabilidade da entidade de destino. Através desta medida, o Ramo deixa de processar as remunerações do militar. Esta medida deve ser executada aquando da “saída” do militar do Ramo, pelo motivo da nova colocação. O militar mantém o status atual.

A entidade de destino (se pertencente ao MDN) deverá executar a medida Admissão/Colocação que representa a primeira colocação do militar nessa entidade, ou a medida Readmissão/Nova Colocação que representa uma nova colocação do militar nessa entidade, ambas com a indicação de que o seu vencimento será processado por esta entidade.

A Medida Colocação (outra Entidade) com processamento partilhado deverá ser executada quando um militar é colocado noutra entidade (pertencente ao MDN ou não), sendo o processamento do seu vencimento partilhado entre ambas as entidades (pelo Ramo e pela entidade de destino). Esta medida deve ser executada aquando da “saída” do militar do Ramo, pelo motivo da nova colocação. O militar passa à situação de “Adido ao quadro”.

A entidade de destino (se pertencente ao MDN) deverá executar a medida Admissão/Colocação que representa a primeira colocação do militar nessa entidade, ou a medida Readmissão/Nova Colocação que representa uma nova colocação do militar nessa entidade, ambas com a indicação de que parte do seu vencimento será processada por esta entidade.

A Medida Colocação (Fora Est. Org. FFAA) deverá ser executada quando o militar é colocado noutra entidade (fora da Estrutura Orgânica das Forças Armadas), sendo o processamento do seu vencimento da responsabilidade da entidade de destino. Através desta medida, o Ramo deixa de processar as remunerações do militar. Esta medida deve ser executada aquando da “saída” do militar do Ramo, pelo motivo da nova colocação. O militar passa à situação de “Adido ao quadro” e mantém o status atual.

A entidade de destino (se pertencente ao MDN) deverá executar a medida Admissão/Colocação que representa a primeira colocação do militar nessa entidade, ou a medida Readmissão/Nova Colocação que representa uma nova colocação do militar nessa entidade, ambas com a indicação de que o seu vencimento será processado por esta entidade.

É relevante referir que as missões, ações de cooperação técnico-militar (por um mínimo de um ano), cursos e cargos no estrangeiro encontram-se englobados neste ponto para os casos em que a nomeação para esta situação dá origem a uma colocação, passando o militar à situação de adido.   
O desempenho de funções de dirigente também se encontra englobado neste ponto, pois o início de uma comissão de serviço como dirigente irá implicar uma nova colocação, sendo possíveis as várias hipóteses descritas quanto ao processamento de vencimentos.

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre  Registo &quot; Medidas</td></tr><tr><td>Código de Transação</td><td>PA40</td></tr></table>

# 5.2.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

# Medidas

#

Pesquisa de

Pessoa

Ajuda para pesquisa coletiva Termo de pesquisa Pesquisa ivre

![](images/26838dd14b81e7e111b48d23c86a2e27fb586ee2fea42f827c8510cb6b47f023.jpg)

![](images/e296a879f40e06c22ee2d072840b58657c5d3b0c859e33f36e5e8474763dfabf.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Selecionar medida</td><td rowspan=1 colspan=1>AQ - Colocação (F.RamoEst.Org.FFAA)ouAR  Colocação (Outra Entidade) comProcessamento PartilhadoouCC  Colocação (Fora Est.Org.FFAA)</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>Preencher com o N° de pessoal para oqual se vai efetuar a alteração</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Início</td><td rowspan=1 colspan=1>A preencher com a data do motivo damedida</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

# 5.2.2. Medida - Tela Geral

# Preencher os seguintes campos:

![](images/07fc082d710f5f3fb73a1c9d87bdceab7f40038888f3d774dac1402ab0fc432b.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">N° de pessoal</td><td colspan="1" rowspan="1">Preenchimento automático</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Válido</td><td colspan="1" rowspan="1">Preenchimento automático</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Válido até</td><td colspan="1" rowspan="1">Preenchimento automático</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Medida</td><td colspan="1" rowspan="1">Preenchimento Automático:AQ  Colocação (F.RamoEst.Org.FFAA)ouAR  Colocação (Outra Entidade) comProcessamento PartilhadoouCC  Colocação (Fora Est.Org.FFAA)</td><td colspan="1" rowspan="1">Depende do tipo de medidaselecionada</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Motivo da medida</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">Posição</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">Área de Recursos Humanos</td><td colspan="1" rowspan="1">Manter valor</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1">Grupo de Empregados</td><td colspan="1" rowspan="1">Manter valor</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">9</td><td colspan="1" rowspan="1">Subgrupo de Empregados</td><td colspan="1" rowspan="1">Manter valor</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">Gravar</td><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1"></td></tr></table>

# 5.2.3. Infotipo 0001 – Atribuição Organizacional

Preencher os seguintes campos:

![](images/454c6730138cc8a071d8ae91e4b2987861d5b531eecf93fb45f1390ebe043127.jpg)

#

![](images/88bdf17d497566f811b31f9aff97c074b628ea7eb75069877450771c73e11806.jpg)

Administração da organização info...

<table><tr><td>Nº pessoal</td><td colspan="2">50112260</td><td>Contr.</td><td colspan="2">50112260 50082513 50112260 ( 1</td></tr><tr><td>Nome</td><td colspan="2">DANIEL JORGE RODRIGUES MAGRO</td><td></td><td colspan="2"></td></tr><tr><td>Grupo empreg</td><td colspan="2">A Militares QP Área RecsHum</td><td>5000 Força Aérea</td><td colspan="2">Nº Ident. 112260</td></tr><tr><td>SubgrpEmprg.</td><td colspan="2">A1 Activo</td><td colspan="2">212000Primeiro-Sargento</td></tr><tr><td>Válido</td><td>01.09.2018</td><td>Posto/Cat. até 31.12.9999</td><td colspan="2"></td></tr></table>

![](images/a30c1cbe50afcdfdeb8c887e5b3b5e80160cc7a4822463946d51f229355f3b15.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Centro Financeiro</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Deverá ser utilizada a ajuda depesquisa para selecionar o valormais adequado para o efeito</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Fundos</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Área Funcional</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Relação de emprego</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Este campo deverá serpreenchido quando o indivíduocontratado seja pago pororganismo externo</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Chave Organizativa</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Preenchido automaticamente</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">Situação na Unidade</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Campo exclusivo da Marinha</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">Gravar</td><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1"></td></tr></table>

# 5.2.4. Infotipo 9011 – Movimentos Mobilidade

Preencher os seguintes campos do Subtipo 0005 – Colocações/Destacamentos:

![](images/975618c63da9ae80cf46a4912ae6b175950efff54d9381042e725ea34768cf55.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Válido</td><td rowspan=1 colspan=1>A preencher com a data de inicio damobilidade</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Válido até</td><td rowspan=1 colspan=1>A preencher com 31.12.9999</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Unidade Destino</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Unidades destino Externas</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Data Prevista</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Data despacho autorizador</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Entidade que Autoriza</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Tipo Nomeação</td><td rowspan=1 colspan=1>09  Não aplicável</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>Tipo Colocação</td><td rowspan=1 colspan=1>03 - Não aplicável</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>Tipo Comissão</td><td rowspan=1 colspan=1>06  Não aplicável</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>Urgência Movimento</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>Status Movimento</td><td rowspan=1 colspan=1>2 - Realizado</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>Data Limite para Movimento</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td></tr></table>

# 5.2.5. Infotipo 0019 - Monitorização de prazos

Preencher os seguintes campos:

![](images/e48798c804b520c82abc6972ea34400222244e97fce1ba68b9b44f873633140e.jpg)

# Monitorização de prazos criar

#

![](images/60e8e6e0ad028db0929ecd2f01299f201cac648e00577aa36413d398f49f7817.jpg)

![](images/0563bebfa42b04e3dae2c61880d6b1506f2d13549b3cbb776456341cbd39f1c4.jpg)

![](images/b9448ae0fce218cc53c043731419cce92d527823d6fc9597a50c83742af8001e.jpg)

Observações

![](images/1c14d87b82597166002fd0a3d739cb40a7054dfa217e2dfceda5669f44dd8712.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Tipo de Datas/Prazos</td><td rowspan=1 colspan=1>e.g Fim da Mobilidade</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Data em</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Data de Fim da Mobilidade</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Código de processamento</td><td rowspan=1 colspan=1>e.g Data nova</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Data de lembrete</td><td rowspan=1 colspan=1>e.g. 01.12.2015</td><td rowspan=1 colspan=1>Data para lembrete do Fim daMobilidade</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1></td></tr></table>

De seguida vão surgir diversos Infotipos que só devem ser preenchidos caso seja necessário alterar/criar algum dado:

Infotipo 0007 – Horário de Trabalho;   
Infotipo 0008 - Remuneração Base; Infotipo 0337 – Posto / Categoria Profissional;   
Infotipo 0332 – Dados Segurança Social / CGA;

No caso da Colocação noutra Entidade com Processamento Partilhado ou da Colocação noutra Entidade sem Processamento também irão surgir os seguintes infotipos:

Infotipo 0052 – Garantia de Rendimento;   
Infotipo 0014 – Remunerações / Deduções Periódicas;   
Infotipo 0057 – Afiliações;   
Infotipo 0045 – Empréstimos / Prestações.

# 5.3. Regresso ao Ramo

Aquando do término de uma “Colocação (fora do Ramo)” (independentemente da forma do processamento de vencimentos), a entidade (pertencente ao MDN) que acolheu o militar deverá executar a medida de Saída com o motivo “Fim de colocação de militar”, indicando assim o fim desta relação com o militar e suspendendo o processamento do seu vencimento, quando aplicável.

Neste momento, aquando da apresentação do militar no Ramo, deverá ser executada a medida Regresso ao Ramo (supranumerário) ou Regresso ao Ramo (no quadro) que têm como objetivo registar o regresso do militar ao Ramo para a unidade de destino respetiva, na situação de “supranumerário” ou “no quadro” respetivamente, repondo o seu processamento de vencimento (caso tenha sido alterado).

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre → Registo &quot; Medidas</td></tr><tr><td>Código de Transação</td><td>PA40</td></tr></table>

# 5.3.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

# Medidas

#

# Pesquisa de

Pessoa

Ajuda para pesquisa coletiva HTermo de pesquisa Pesquisa livre

![](images/932073f7451216282d9b139aa6d7d9920d0038055915cc714b3bd19e6e3efb1b.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Selecionar medida</td><td rowspan=1 colspan=1>AT - Regresso ao Ramo (supranum.)ouAU - Regresso ao Ramo (no quadro)</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>Preencher com o N° de pessoal para oqual se vai efetuar a alteração</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Início</td><td rowspan=1 colspan=1>A preencher com a data do motivo damedida</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1></td></tr></table>

# 5.3.2. Medida - Tela Geral

Preencher os seguintes campos:

![](images/8da4cc155f9bd2ecec60a2fbfa22948ba417ae86ed07c2eaef922d2725cab88f.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>-</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>Preenchimento automático</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Válido</td><td rowspan=1 colspan=1>Preenchimento automático</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Válido até</td><td rowspan=1 colspan=1>Preenchimento automático</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Medida</td><td rowspan=1 colspan=1>Preenchimento Automático:AT  Regresso ao Ramo (supranum.)ouAU - Regresso ao Ramo (no quadro)</td><td rowspan=1 colspan=1>Depende do tipo de medidaselecionada</td></tr></table>

<table><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Motivo da medida</td><td rowspan=1 colspan=1>01 - Regresso - s/vacatura Q.Esp.01 - Regresso ao Ramo</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Posição</td><td rowspan=1 colspan=1>A preencher</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1>Manter valor</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Grupo de Empregados</td><td rowspan=1 colspan=1>Manter valor</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>Subgrupo de Empregados</td><td rowspan=1 colspan=1>Manter valor</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td></tr></table>

# 5.3.3. Infotipo 0001 – Atribuição Organizacional

Preencher os seguintes campos:

![](images/778c465dfe263349a8bee5d88f0d03894d9b73ab91e16aefdbb42658b2d230d5.jpg)

#

![](images/f919c8379ccf4e0c8459a56a63918e44b5a9216319a22d82f6a34f85a94da2ac.jpg)

Administração da organização info...

<table><tr><td>Nº pessoal</td><td colspan="2">50112260</td><td>Contr.</td><td colspan="2">50112260 50082513 50112260 ( 1</td></tr><tr><td>Nome</td><td colspan="2">DANIEL JORGE RODRIGUES MAGRO</td><td></td><td colspan="2"></td></tr><tr><td>Grupo empreg</td><td colspan="2">A Militares QP Área RecsHum</td><td>5000 Força Aérea</td><td colspan="2">Nº Ident. 112260</td></tr><tr><td>SubgrpEmprg.</td><td colspan="2">A1 Activo</td><td colspan="2">212000Primeiro-Sargento</td></tr><tr><td>Válido</td><td>01.09.2018</td><td>Posto/Cat. até 31.12.9999</td><td colspan="2"></td></tr></table>

![](images/a4dab50de3a884d70d4b9220c4b6c9152613e977cb29a22d67ce4918867c72e9.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Centro Financeiro</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Deverá ser utilizada a ajuda depesquisa para selecionar o valormais adequado para o efeito</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Fundos</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Área Funcional</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Relação de emprego</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Este campo deverá serpreenchido quando o indivíduocontratado seja pago pororganismo externo</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Chave Organizativa</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Preenchido automaticamente</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">Situação na Unidade</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Campo exclusivo da Marinha</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">Gravar</td><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1"></td></tr></table>

De seguida vão surgir diversos Infotipos que só devem ser preenchidos caso seja necessário alterar/criar algum dado:

Infotipo 0008 - Remuneração Base;   
Infotipo 0337 – Posto / Categoria Profissional;   
Infotipo 0332 – Dados Segurança Social / CGA;   
Infotipo 0014 – Remunerações / Deduções Periódicas;   
Infotipo 0057 – Afiliações;   
Infotipo 0045 – Empréstimos / Prestações.   
Infotipo 0033 – Outros Dados

# 5.3.4. Infotipo 9011 – Movimentos Mobilidade

Preencher os seguintes campos:

# Movimentos mobilidades Delimitar

![](images/e36761bc4043b6e2f79d7234b213bd70cf1c183047d7bb9ca68c287060183b15.jpg)

![](images/092e03dec469414e57de62e56c00954c7d7664901a4efb770f6503e523d88147.jpg)

![](images/7c5c7dcae9b4c09e2549252efae424583e268b29a3b26c841eefb73656d5a8a9.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Subitpo</td><td colspan="1" rowspan="1">Selecionar linha</td><td colspan="1" rowspan="1"></td></tr><tr><td>2</td><td>Delimitar</td><td>7 Selecionar</td><td></td></tr></table>

# 5.4. Diligência/Destacamento

Neste ponto do documento serão abordados os seguintes tipos de movimento:

• Início e fim de Diligências (dentro ou para fora do Ramo);   
• Início e fim de Destacamentos.

Para o início de diligências e destacamentos deverá ser registada uma mesma medida, com o motivo correspondente. O fim de uma diligência ou de um destacamento corresponde ao registo de uma outra medida.

Através do registo destas medidas, o sistema irá copiar determinados IT (com base nos IT já existentes), cuja informação será alterada pelo utilizador, indicando o período a partir do qual são válidos os novos dados acerca do militar; outros registos serão delimitados, pois deixarão de estar válidos e serão ainda criados novos registos de informação que deverá ser atualizada pelo utilizador.

No caso do início de uma diligência ou de um destacamento, a medida irá propor ao utilizador a criação do IT “Informação sobre Movimentos/Mobilidades”, mais precisamente o subtipo “Diligências/Destacamentos”. Data de início – deve ser registada a data na qual o registo foi criado;

Data de fim – deve ser colocada a data 31.12.9999; no momento em que o militar regressa da situação de diligência, este registo será delimitado pela medida correspondente ao final desta situação (explicada em seguida); • Unidade organizacional – deve ser seleccionada a unidade organizacional para a qual o militar se movimentará (este campo terá uma ajuda de pesquisa associada que permite seleccionar as unidades criadas na estrutura organizacional); estará disponível um campo de texto livre para os casos em que o movimento é para fora do MDN; Data prevista da marcha – registar a data de movimentação que foi previamente autorizada; • Despacho autorizador do movimento – identificar o Despacho que dará origem ao movimento (este campo será de texto livre); • Missão a desempenhar – deve ser registada a missão que origina o movimento.

A informação registada neste IT permite emitir a Guia de marcha que deve acompanhar o militar quando se desloca para fora da sua UEOS. A forma como este documento será emitido está referida no ponto 6. Necessidade de layout do presente documento.

As medidas relevantes são as seguintes:

A Medida Diligência / Destacamento tem por objetivo registar uma destas duas situações. Em qualquer um dos casos, o Ramo continua a processar as remunerações ao militar, que continua a ocupar vaga na estrutura. Através desta medida, para a diligência ou do destacamento, o utilizador apenas irá criar determinados IT para ter a indicação da unidade onde se encontra o militar (por exemplo, será criado o IT mencionado acima).

• A Medida Fim de diligência/destacamento deverá ser executada quando um militar termina a diligência ou destacamento. Esta medida irá delimitar o registo do IT “Informação sobre Movimentos/Mobilidades” criado com a medida anterior.

É relevante referir que as missões, ações de cooperação técnico-militar (por um período inferior a um ano), cursos e cargos no estrangeiro encontram-se englobados neste ponto para os casos em que a nomeação para esta situação dá origem a uma diligência, não sendo alterada a situação do militar em relação ao quadro (e sendo o Ramo responsável pelos encargos com a sua remuneração). Nestes casos específicos, quando existe o pagamento de um abono por parte da entidade de destino (por exemplo, EMGFA), esta entidade deverá registar a medida de Admissão/Colocação ou a medida Readmissão/Nova Colocação, como foi explicado anteriormente para os casos de colocações fora do Ramo onde a entidade de destino tem encargos com parte da remuneração do militar.

<table><tr><td>Menu</td><td>HR  Recursos Humanos  Dados Mestre  Registo → Medidas</td></tr><tr><td>Código de Transação</td><td>PA40</td></tr></table>

# 5.4.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

# Medidas

![](images/62834d276d1493364e1a88fa6e29b5d4ef5729cb498db5a97ddd2f1f896896d8.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Selecionar medida</td><td rowspan=1 colspan=1>AV - Diligência/Destacamento-InícioAW  Diligência/Destacamento-Fim</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>Preencher com o N° de pessoal para oqual se vai efetuar a alteração</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Início</td><td rowspan=1 colspan=1>A preencher com a data do motivo damedida</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

# 5.4.1. Medida - Tela Geral

Preencher os seguintes campos:

![](images/ca714724d5e0e2cee81eaabb143dbf9819ae3a3fa6147ce6816d665b4851bb33.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">-</td><td colspan="1" rowspan="1">N° de pessoal</td><td colspan="1" rowspan="1">Preenchimento automático</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Válido</td><td colspan="1" rowspan="1">Preenchimento automático</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Válido até</td><td colspan="1" rowspan="1">Preenchimento automático</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Medida</td><td colspan="1" rowspan="1">Preenchimento AutomáticoAV  Diligência/Destacamento-InícioAW  Diligência/Destacamento-Fim</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Motivo da medida</td><td colspan="1" rowspan="1">Selecionar</td><td colspan="1" rowspan="1"></td></tr><tr><td>6</td><td>Posição</td><td>A preencher</td><td></td></tr><tr><td>7</td><td>Área de Recursos Humanos</td><td>Manter valor</td><td></td></tr><tr><td>8</td><td>Grupo de Empregados</td><td>Manter valor</td><td></td></tr><tr><td>9</td><td>Subgrupo de Empregados</td><td>Manter valor</td><td></td></tr><tr><td>10</td><td>Gravar</td><td>8</td><td></td></tr></table>

# 5.4.2. Infotipo 0001 – Atribuição Organizacional

Preencher os seguintes campos:

![](images/80b03fb412534bebfa3261c0772571c592f1f0f659fbb5278f30fcd9d273ecb7.jpg)

# Atribuição organizacio.ICopiar 0

![](images/a49dfdb0cdef4d0a246cca48f622046140e3d803c87c1eacead713c31f9375b2.jpg)

Administração da organização info...

![](images/5c0425bf99076c112584694597773b841ef09bba584a893aeac3b7277e2a163d.jpg)

![](images/8bb2d43289e15f516d0b191b0eb00ca028ebf7565bc9ba5b528862df7a866c93.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Centro Financeiro</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Deverá ser utilizada a ajuda depesquisa para selecionar o valormais adequado para o efeito</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Fundos</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Área Funcional</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Relação de emprego</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Este campo deverá serpreenchido quando o indivíduocontratado seja pago pororganismo externo</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Chave Organizativa</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Preenchido automaticamente</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">Situação na Unidade</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Campo exclusivo da Marinha</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">Gravar</td><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1"></td></tr></table>

# 5.4.3. Infotipo 9011 – Movimentos Mobilidade

Preencher os seguintes campos do Subtipo 0005 – Colocações/Destacamentos:

![](images/ecd66644f970844dc78bda41ab284e42217edad8d09688aa1ea1b028905ff994.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Válido</td><td rowspan=1 colspan=1>A preencher com a data de inicio damobilidade</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Válido até</td><td rowspan=1 colspan=1>A preencher com 31.12.9999</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Unidade Destino</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Unidades destino Externas</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Data Prevista</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Data despacho autorizador</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Entidade que Autoriza</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Tipo Nomeação</td><td rowspan=1 colspan=1>Selecionar</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>Tipo Colocação</td><td rowspan=1 colspan=1>Selecionar</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>Tipo Comissão</td><td rowspan=1 colspan=1>Selecionar</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>Urgência Movimento</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>Status Movimento</td><td rowspan=1 colspan=1>2 - Realizado</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>Data Limite para Movimento</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td></tr></table>

![](images/dd794de38670d9b21af4cc5df865035caef51f3d452805b19844dbab4a9bf253.jpg)

![](images/e50feffa77b9d44f760d2605af801bffc18b2b8e1aa7ac7c997afd47b34f354c.jpg)

# Movimentos mobilidades criar

![](images/fe9372a4e97ecca3fe6f1716ba6c033be396d23f6804f9f51a7a15a16399e2e4.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Válido de</td><td colspan="1" rowspan="1">A preencher com a data de início doregisto (dia atual)</td><td colspan="1" rowspan="1">Deve ser inserida a data deinício  dasituação deinamovibilidade.</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Válido até</td><td colspan="1" rowspan="1">A preencher com a data de fim doregisto</td><td colspan="1" rowspan="1">Deve ser colocada a data até àqual o militar se encontra emsituação de inamovibilidade.</td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Situação</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Obrigatório.</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Deve ser indicada se o registocorresponde à situação inicialde inamovibilidade ou umaprorrogação (1ª, 2ª ou 3ª).</td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Órgão</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Obrigatório.Deve ser selecionado o Órgão aque o militar pertence e que éum elemento caracterizador dasituação de inamovibilidade.</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Função</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Obrigatório.Selecionar a função que omilitar exerce e que também elacaracteriza a situação emquestão.</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">Gravar</td><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1"></td></tr></table>

# 5.4.4. Infotipo 0019 - Monitorização de prazos

Preencher os seguintes campos, exclusivamente para o motivo 01-Colocação. Para a Consolidação e Fim de mobilidade deve passar ao registo seguinte:

![](images/1936c97cd543c347ce77d456945a48bfea3a704e3908443f1dddd46fcda94da2.jpg)

# Monitorização de prazus criar

#

![](images/8d591952434aeba9c812c2c9d8918ef911e2fe919c3b9e5930173c9fe1f2f911.jpg)

![](images/268f6bacc49b8fbbfe9514e6b60b245b812b63591868d4e00badd1ad41376ffc.jpg)

![](images/81366586974ab549125e2f3d811f0f637dcefd42294649d447744fa6f6249305.jpg)

Específico de tipo de datas/prazos

# Observações

![](images/ca9cb6751c125ecdc0eb09f0fa3e7ce86b734e8bff22b9d9c5a5aa327ee1d9f6.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Tipo de Datas/Prazos</td><td rowspan=1 colspan=1>e.g Fim Mobilidade</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Data em</td><td rowspan=1 colspan=1>Preencher</td><td rowspan=1 colspan=1>Data Fim da Mobilidade</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Código de processamento</td><td rowspan=1 colspan=1>e.g Data nova</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Data de lembrete</td><td rowspan=1 colspan=1>e.g. 01.12.2015</td><td rowspan=1 colspan=1>Data para lembrete do Fim daMobilidade</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1></td></tr></table>

# 5.5. Alteração de situação na unidade

Este ponto do documento pretende responder a uma especificidade da Marinha.

Tal como foi referido anteriormente, um militar pode ter uma alteração da sua situação na unidade de origem ou uma nova situação noutra unidade, mantendo-se a sua situação na unidade de origem, sem que ocorra um dos movimentos já descritos (colocação, diligência e destacamento). Para estes casos, existe a medida de Alteração da situação na unidade. Esta medida irá apresentar os ITs 0000 - Medidas e 0001 – Atribuição organizacional. Será ainda apresentada uma tela onde será visível a indicação da Posição (ou Posições) às quais o militar se encontra associado na estrutura organizacional (os conceitos de Posição e estrutura organizacional são detalhados nos documentos correspondentes ao Macro-processo 1. Planear necessidades e despesas com pessoal). Nessa tela, o utilizador poderá alterar o campo correspondente à “situação na unidade” do militar para cada Posição apresentada ou ainda registar o fim da associação do militar a uma dessas Posições ou associá-lo a uma outra Posição indicando a respetiva situação, sendo estas associações refletidas ao nível da estrutura organizacional. É importante salientar que o militar tipicamente estará a apenas uma Posição, correspondente à unidade de origem, mas poderão ser várias, como para os casos de acumulação por exemplo. Desta forma, o utilizador mantém o registo da situação do militar em relação a cada unidade relevante.

<table><tr><td>Menu</td><td>HR  Recursos Humanos &quot; Dados Mestre → Registo → Medidas</td></tr><tr><td>Código de Transação</td><td>PA40</td></tr></table>

# 5.5.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

![](images/eba7d0634421845d1e3793722dfaad23f6f736e8b68f21fe704e4a9fd88e8db3.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Selecionar medida</td><td rowspan=1 colspan=1>AX  Alt. Situação na unidade</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>Preencher com o Nº de pessoal para oqual se vai efetuar a alteração</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Início</td><td rowspan=1 colspan=1>A preencher com a data do motivo damedida</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1></td></tr></table>

# 5.5.2. Medida - Tela Geral

Preencher os seguintes campos:

![](images/a3656af677f943a6fa2f8fc6fad93e0af2b70cb6c636ae742bdc9074cdbd11c1.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>N° de pessoal</td><td rowspan=1 colspan=1>Preenchimento automático</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Válido</td><td rowspan=1 colspan=1>Preenchimento automático</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Válido até</td><td rowspan=1 colspan=1>Preenchimento automático</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Medida</td><td rowspan=1 colspan=1>AX  Alt. Situação na unidade</td><td rowspan=1 colspan=1>cYanlowb</td></tr></table>

<table><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Motivo da medida</td><td rowspan=1 colspan=1>01  Alt. Situação na unidade</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Posição</td><td rowspan=1 colspan=1>A preencher</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1>Manter valor</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Grupo de Empregados</td><td rowspan=1 colspan=1>Manter valor</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>Subgrupo de Empregados</td><td rowspan=1 colspan=1>Manter valor</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>Gravar</td><td rowspan=1 colspan=1>8</td></tr></table>

# 5.5.3. Infotipo 0001 – Atribuição Organizacional

Preencher os seguintes campos:

![](images/6958edd148be5789df8bc2f9880925732b154648b786a81c75ff33f5d60d285d.jpg)

# Atribuição organizacio.ICopiar 0

![](images/f0289a965600551e1d5b973b9afe3d304a58ac1a4cb82f6008db2300d0b3a7bf.jpg)

Administração da organização info...

![](images/e75556f252601777bfa0298d7bac4319c31fcb768314fdd0f07c563e82f2c708.jpg)

![](images/3b907a80e2b66e494041cf22311b6ba50c14349eddc0a6775abd4604b2d6e3c2.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Centro Financeiro</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1">Deverá ser utilizada a ajuda depesquisa para selecionar o valormais adequado para o efeito</td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Fundos</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Área Funcional</td><td colspan="1" rowspan="1">A preencher</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">Relação de emprego</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Este campo deverá serpreenchido quando o indivíduocontratado seja pago pororganismo externo</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Chave Organizativa</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">Preenchido automaticamente</td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">Situação na Unidade</td><td colspan="1" rowspan="1">Alterar</td><td colspan="1" rowspan="1">Campo exclusivo da Marinha</td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">Gravar</td><td colspan="1" rowspan="1">8</td><td colspan="1" rowspan="1"></td></tr></table>

# 5.6. Suplemento de Residência

No âmbito deste processo, será abordada a candidatura do militar ao suplemento de residência por prestação de serviço em UEOS fora da Área de Preferência.

O Órgão Gestor de Pessoal ou às UEOS (dependendo do Ramo em questão) procedem à verificação das condições legais de atribuição deste suplemento através da validação do processo de candidatura enviado pela UEOS de colocação do militar, e tendo em conta a residência que está registada em sistema (no IT0006 – Endereços) e a declaração de unidade de preferência (registada no IT “Informação para Movimentos/Mobilidades”, subtipo “Área de preferência”). Uma vez reunidas as condições, deve ser efetuado no sistema o registo da atribuição deste suplemento e efetuada a publicação em Ordem de Serviço. Em SAP, para garantir a integração com o processo de vencimentos, deve ser criado um registo no IT0014 – Remunerações/deduções periódicas com a indicação da rubrica salarial criada para o efeito. Aquando da criação do registo, deve ser inserida, para além da respetiva rubrica, a data de início do abono (data a partir da qual será pago o suplemento, num período máximo de 5 anos) e a percentagem / escalão a que o militar tem direito. Desta forma, estão garantidas as condições para que o abono seja processado a nível de vencimentos.

Quando ocorre o cancelamento deste suplemento, ou seja, uma vez verificada a perda do direito de atribuição, deve ser atualizado o registo em SAP, efetuada a publicação em Ordem de Serviço e enviada informação ao órgão processador de vencimentos. O cancelamento do suplemento de residência traduz-se na delimitação do registo no IT0014 – Remunerações/deduções periódicas, previamente criado com a indicação da rubrica salarial referente a este abono. A delimitação do registo válido fará com que o abono que estava a ser mensalmente concedido ao militar deixe de ser processado a partir da data a que o IT for delimitado, não perdendo, com esta ação, a informação relativa ao histórico do registo, ou seja, o registo permanece associado ao militar, embora não lhe seja abonado o suplemento de residência.

Para obter um maior detalhe relativamente à forma como este abono é processado, devem ser consultados os documentos do Macro-processo 6. Vencimentos.

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre → Registo  Exibir</td></tr><tr><td>Código de Transação</td><td>PA20</td></tr></table>

# 5.6.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

# Exibir dados mestre HR

![](images/fb79ee309bcb3abd09f81f3ea4a88dacfde5eb0f0bdab8fe494290fa847e692c.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Nº de pessoal</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Infotipo</td><td rowspan=1 colspan=1>0006 - Endereços</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Subtipo</td><td rowspan=1 colspan=1>1  Residência Permanente</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Exibir</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Exibe o registo</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Síntese</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Lista todos os registos</td></tr></table>

# 5.6.2. Infotipo 0006 – Endereços

![](images/886fbfcf2995dec9c765502e2ad35160a50cce65ad333315b3c4163fd2711f6d.jpg)

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Dados Mestre → Registo → Exibir</td></tr><tr><td>Código de Transação</td><td>PA20</td></tr></table>

# 5.6.1. Ecrã inicial

Preencher os seguintes campos obrigatórios:

# Exibir dados mestre HR

![](images/c06748967a7638cdd89b1e0339576dc388e8e8d4a92b1791f7d37e4d1dbbbbb6.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Nº de pessoal</td><td rowspan=1 colspan=1>A preencher</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Infotipo</td><td rowspan=1 colspan=1>9011 - Movimentos Mobilidades</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Subtipo</td><td rowspan=1 colspan=1>0001 - Área de Preferência</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>Exibir</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Exibe o registo</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Síntese</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>Lista todos os registos</td></tr></table>

# 5.6.2. Infotipo 9011 – Movimentos e Mobilidades

<table><tr><td>Válido</td><td>18.11.2013</td><td>até</td><td>31.12.9999</td><td>Mod.</td><td>07.09.2018 D0001173</td><td></td></tr><tr><td colspan="7">Movimentos mobilidades</td></tr><tr><td colspan="7">Área de preferência</td></tr><tr><td colspan="3">Área Preferência Unidade Preferência</td><td></td><td>400099 Outra</td><td rowspan="5"></td></tr><tr><td colspan="4"></td><td></td></tr><tr><td colspan="3">Data entrega da declaração de preferência</td><td>0 30.03.2017</td><td colspan="2"></td></tr><tr><td colspan="4"></td><td>31.12.9999</td></tr><tr><td colspan="3">Data do despacho autorizador</td><td></td><td colspan="2"></td></tr></table>

# 5.7. Extração da informação

# 5.7.1. Dados necessários à elaboração da Guia de marcha

<table><tr><td>Menu</td><td>HR - Recursos Humanos → Gestão de Pessoal  Processo Individual → Assiduidades → Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0030</td></tr></table>

Preencher os seguintes campos:

![](images/d524a4b2b15f108addae0b3ddbc313831c6ad83b1a9f0486f40fcd5d77d7cd58.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Chamar variante</td><td colspan="1" rowspan="1">F</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Opção</td><td colspan="1" rowspan="1">GUIA MARCHA</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Selecionar</td><td colspan="1" rowspan="1">V</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">N° Pessoal</td><td colspan="1" rowspan="1">A Preencher com o Nº de pessoal</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">Área de Recursos Humanos</td><td colspan="1" rowspan="1">cYanelob</td><td colspan="1" rowspan="1"></td></tr><tr><td>6</td><td>Tipo da identificação (tipo ID)</td><td>Preencher o campo caso pretenda obter informação acerca de um tipo de identificação específico</td><td></td></tr><tr><td>7</td><td>Executar</td><td>O</td><td></td></tr></table>

5.7.2. Listagem dos militares que completam o tempo máximo a receber Suplemento de Residência, numa determinada data

<table><tr><td>Menu</td><td>HR - Recursos Humanos → Gestão de Pessoal → Movimentação de Pessoal &quot; Relatórios</td></tr><tr><td>Código de Transação</td><td></td></tr><tr><td></td><td>ZHR_T_Q0001</td></tr></table>

Preencher os seguintes campos:

![](images/880287a92c1ab041140e9e0d3424c621379c189836cdff5402965fcf40d14d42.jpg)

<table><tr><td colspan="1" rowspan="1">#</td><td colspan="1" rowspan="1">Campo / Operação</td><td colspan="1" rowspan="1">Valores</td><td colspan="1" rowspan="1">Comentários</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">Chamar variante</td><td colspan="1" rowspan="1">F</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">Opção</td><td colspan="1" rowspan="1">SUPLEM.RESIDEN</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">Selecionar</td><td colspan="1" rowspan="1">V</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">N° Pessoal</td><td colspan="1" rowspan="1">A Preencher com o Nº de pessoal</td><td colspan="1" rowspan="1"></td></tr><tr><td>5</td><td>Área de Recursos Humanos</td><td></td><td></td></tr><tr><td>6</td><td>Rubrica Salarial</td><td></td><td></td></tr><tr><td>7</td><td>Tipo da identificação (tipo ID)</td><td>Preencher o campo caso pretenda obter informação acerca de um tipo de identificação específico</td><td></td></tr><tr><td>8</td><td>Executar</td><td>+</td><td></td></tr></table>

# 5.7.3. Listagem de militares com suplemento de residência processado num determinado período

<table><tr><td>Menu</td><td>HR  Recursos Humanos → Vencimentos  Relatórios  Abonos/Descontos</td></tr><tr><td>Código de Transação</td><td>S_AHR_61016170</td></tr></table>

Preencher os seguintes campos:

![](images/8e0e426af5cfbc88d20fd46319c7e3e43284766d18f042bcf359feb55f4748df.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>SUPLEM.RESIDEN</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o N° de pessoal</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Rubrica Salarial</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Infotipo</td><td rowspan=1 colspan=1>0014 - Remunerações/deduções periódicas</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Moeda de saída</td><td rowspan=1 colspan=1>EUR</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>④</td></tr></table>

5.7.4. Listagem dos Suplementos de Residência cancelados num determinado período

<table><tr><td>Menu</td><td>HR - Recursos Humanos &quot; Gestão de Pessoal  Movimentação de Pessoal → Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0001</td></tr></table>

Preencher os seguintes campos:

![](images/0a58c98b4babf0a2bacd1e2f1ae9851f0cda3ccef467f3bebfad93f93be837e6.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>SUP.RES.CANCEL</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o N° de pessoal</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Rubrica Salarial</td><td rowspan=1 colspan=1>Preencher o campo caso se pretenda obteruma lista para um numero/conjunto denúmeros específicos</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Início da validade</td><td rowspan=1 colspan=1>e.g 01.01.2018</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Fim da validade</td><td rowspan=1 colspan=1>e.g 31.08.2018</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>+</td></tr></table>

# 5.7.5. Lista de unidades de preferência

<table><tr><td>Menu</td><td>HR - Recursos Humanos  Gestão de Pessoal → Movimentação de Pessoal → Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0062</td></tr></table>

Preencher os seguintes campos:

![](images/6a74ad3dfa3743a8640361c84433b46c63194601dfa315b1af45eca45bd84ed0.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>UNIDADE PREF.</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o Nº de pessoal</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Tipo de Documento</td><td rowspan=1 colspan=1>Selecionar o tipo de documento para o qualpretende obter informação</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>0</td><td rowspan=1 colspan=1></td></tr></table>

# 5.7.6. Lista de colocações/unidade de colocação

<table><tr><td>Menu</td><td>HR  Recursos Humanos &quot; Gestão de Pessoal  Movimentação de Pessoal ! Relatórios</td></tr><tr><td>Código de Transação</td><td>ZHR_T_Q0006</td></tr></table>

# Preencher os seguintes campos:

![](images/dbb7057eb3f6be7a4062d95a4f545b5b8931bb064b8ba4400de08add73145bee.jpg)

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Campo / Operação</td><td rowspan=1 colspan=1>Valores</td><td rowspan=1 colspan=1>Comentários</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>Chamar variante</td><td rowspan=1 colspan=1>F</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>Opção</td><td rowspan=1 colspan=1>COLOCAÇÕES</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>Selecionar</td><td rowspan=1 colspan=1>V</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>N° Pessoal</td><td rowspan=1 colspan=1>A Preencher com o N° de pessoal</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>Área de Recursos Humanos</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>Subtipo</td><td rowspan=1 colspan=1>Secionar o tipo de movimento para o qualpretende visualizar a lista:0005 - Colocações</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>Executar</td><td rowspan=1 colspan=1>O</td><td rowspan=1 colspan=1></td></tr></table>

Lisboa, 13 de novembro de 2018

O Diretor de Serviços dos Sistemas de Informação